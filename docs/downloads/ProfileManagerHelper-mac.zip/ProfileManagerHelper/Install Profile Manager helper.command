#!/bin/bash
cd "$(dirname "$0")"
if [ "$(uname -m)" = "arm64" ]; then B=darwin-arm64; else B=darwin-amd64; fi
xattr -dr com.apple.quarantine . 2>/dev/null
chmod +x "$B/profile-helper"
"./$B/profile-helper" --install
echo; read -r -p "  Press Enter to close this window..." _
