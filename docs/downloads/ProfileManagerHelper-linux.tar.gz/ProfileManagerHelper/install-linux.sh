#!/bin/bash
# Usage: ./install-linux.sh [Chrome data folder]   (default ~/.config/google-chrome)
cd "$(dirname "$0")"
case "$(uname -m)" in aarch64|arm64) B=linux-arm64;; *) B=linux-amd64;; esac
chmod +x "$B/profile-helper"; "./$B/profile-helper" --install "$1"
